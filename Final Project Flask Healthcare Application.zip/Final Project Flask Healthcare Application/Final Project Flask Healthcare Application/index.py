from flask import Flask, render_template, request
from pymongo import MongoClient
from processing import User
import os

client = MongoClient('mongodb+srv://hestia:qULdFKOycJ3d0iGf@cluster1.pio9p.mongodb.net/?retryWrites=true&w=majority&appName=Cluster1')
db = client['expense_db']
users_collection = db['users']
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def user():
    if request.method == 'POST':
        data = {
            'age': request.form['age'],
            'gender': request.form['gender'],
            'income': request.form['income'],
            'expenses': request.form.getlist('expenses')
        }
        result = users_collection.insert_one(data) 
        if(result.inserted_id):
            return render_template('index.html', response=True)
       
    return render_template('index.html', response=False)

@app.route('/get_users', methods=['GET'])
def get_users():
    filename = 'user_data.csv';
    if os.path.exists(filename):
        os.remove(filename)

    users = list(users_collection.find())
    doc = User(None, None, None, None)  
    doc.to_csv(header=True)

    for user in users:
        doc = User(user['age'], user['gender'], user['income'], user['expenses'][0])
        doc.to_csv()

    return render_template("users.html", users=users)

@app.template_filter('currency')
def format_currency(value):
    return "{:,.0f}".format(float(value))

if __name__ == '__main__':
    app.run(debug=True)
